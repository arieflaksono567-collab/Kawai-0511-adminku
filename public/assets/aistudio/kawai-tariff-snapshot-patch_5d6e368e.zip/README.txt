KAWAI 0511 PATCH PREPARATION

Scope:
1. Make the tariff snapshot migration idempotent per column.
2. Keep schema.sql in sync with the orders table definition.
3. Add nullable snapshot fields to DbOrder for legacy compatibility.
4. Add source-level tests for migration and type contract.

Important limitation:
The GitHub connector returned HTTP 403 Resource not accessible by integration when creating branch fix/security-rls-followup. No remote files were changed. The patch must be applied on a writable branch/repository, then npm test, npm run lint, and npm run build must be executed in a project environment.

This patch does not activate road routing or write tariff snapshots during order creation. The admin repository's src/lib/api.ts does not contain a create-order function; the actual order creation path must be located in the passenger/backend repository before wiring snapshot writes safely.
